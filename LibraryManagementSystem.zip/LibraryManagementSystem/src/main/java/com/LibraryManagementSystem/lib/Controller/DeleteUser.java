package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.Borrowing;
import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteUser{
    public void operations(Record record) {

        JFrame frame = MainPage.frame(400, 210);
        frame.setLayout(new BorderLayout());

        JLabel title = MainPage.title("Delete User");
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        panel.setBackground(null);
        JLabel label = MainPage.label("User Name:");
        JTextField name = MainPage.textfield();
        JButton delete = MainPage.button("Delete User");
        JButton cancel = MainPage.button("Cancel");
        panel.add(label);
        panel.add(name);
        panel.add(delete);
        panel.add(cancel);

        delete.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (name.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "User name cannot be empty!");
                }
                int userIndex = record.getUser(name.getText().toString());
                if (userIndex > -1) {
                    User u = record.getUser(userIndex);
                    boolean isBookBorrowed = isBookBorrowed(record, u);
                    if (isBookBorrowed) {
                        JOptionPane.showMessageDialog(new JFrame(), "User has currently borrowed a book and cannot be deleted!");
                    } else {
                        record.deleteUser(userIndex);
                        JOptionPane.showMessageDialog(new JFrame(), "User deleted successfully!");
                        frame.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(new JFrame(), "User doesn't exist!");
                }
            }
        });
        cancel.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);

    }

    // Check if a book is currently borrowed
    private boolean isBookBorrowed(Record record, User user) {
        for (Borrowing borrowing : record.getBrws()) {
            if (borrowing.getUser().equals(user)) {
                return true;
            }
        }
        return false;
    }
}
