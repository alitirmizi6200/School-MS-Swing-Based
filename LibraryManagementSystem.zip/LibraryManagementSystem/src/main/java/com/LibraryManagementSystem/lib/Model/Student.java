package com.LibraryManagementSystem.lib.Model;

import com.LibraryManagementSystem.lib.Controller.*;
import com.LibraryManagementSystem.lib.Exit;

import javax.swing.JFrame;

public class Student extends User {

	public Student(String name) {
		super(name);
		this.operations = new IOOperation[] {
				new ViewBooks(),
				new PlaceOrder(),
				new BorrowBook(),
				new CalculateFine(),
				new ReturnBook(),
				new Exit()
		};
	}
	
	public Student(String name, String username, String pass) {
		super(name, username, pass);
		this.operations = new IOOperation[] {
				new ViewBooks(),
				new PlaceOrder(),
				new BorrowBook(),
				new CalculateFine(),
				new ReturnBook(),
				new Exit()
		};
	}
	
	@Override
	public void menu(Record database, User user) {
		
		String[] data = new String[6];
		data[0] = "View Books";
		data[1] = "Place Order";
		data[2] = "Borrow Book";
		data[3] = "Calculate Fine";
		data[4] = "Return Book";
		data[5] = "Exit";
		
		JFrame frame = this.frame(data, database, user);
		frame.setVisible(true);
	}
	
	public String toString() {
		return name+"<N/>"+username+"<N/>"+pass+"<N/>"+"Normal";
	}
	
}
