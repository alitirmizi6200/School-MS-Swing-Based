package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.Book;
import com.LibraryManagementSystem.lib.Model.IOOperation;
import com.LibraryManagementSystem.lib.Model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Vector;

public class ViewBooks implements IOOperation {

	private JTextField searchField;
	private DefaultTableModel model;

	@Override
	public void operations(Record record, User user) {

		int rows = record.getAllBooks().size();
		Vector<String> columnNames = new Vector<>(Arrays.asList("Name", "Author", "Publisher", "CLA", "Qty", "Price", "Brw cps"));
		Vector<Vector<Object>> data = new Vector<>();

		for (Book b : record.getAllBooks()) {
			Vector<Object> rowData = new Vector<>();
			rowData.add(b.getName());
			rowData.add(b.getAuthor());
			rowData.add(b.getPublisher());
			rowData.add(b.getAdress());
			rowData.add(b.getQty());
			rowData.add(b.getPrice());
			rowData.add(b.getBrwcopies());
			data.add(rowData);
		}

		JFrame frame = MainPage.frame(1000, 500);

		JLabel title = MainPage.title("View Books");
		frame.getContentPane().add(title, BorderLayout.NORTH);

		model = new DefaultTableModel(data, columnNames);
		JTable table = new JTable(model);

		JScrollPane scrollPane = new JScrollPane(table);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

		JPanel searchPanel = new JPanel();
		searchField = new JTextField(20);

		JButton searchNameButton = new JButton("Search Book by Name");

		JButton searchAuthorButton = new JButton("Search Book by Author");

		JButton searchPublisherButton = new JButton("Search Book by Publisher");
		if(searchField.getText() == ""){
			JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");

		}
		else{
			searchNameButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					String searchTerm = searchField.getText();
					if(searchTerm.toString().matches("")){
						JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");
					}else{searchBooksByNameAuthorPublisher(record,searchTerm,0);}
				}
			});
			searchAuthorButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String searchTerm = searchField.getText();
					if(searchTerm.toString().matches("")){
					JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");

					}
					else{searchBooksByNameAuthorPublisher(record,searchTerm,2);}
				}
			});
			searchPublisherButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					String searchTerm = searchField.getText();
					if(searchTerm.toString().matches("")){
						JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");

					}else{searchBooksByNameAuthorPublisher(record,searchTerm,1);}
				}
			});
		}

		JButton DeleteButton = new JButton("Delete Book");
		DeleteButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String[] a1 = user.toString().split("<N/>");
				DeleteBook del = new DeleteBook();
				del.operations(record,user);
			}
		});
		searchPanel.add(searchField);
		searchPanel.add(searchNameButton);
		searchPanel.add(searchAuthorButton);
		searchPanel.add(searchPublisherButton);
		String[] a1 = user.toString().split("<N/>");


		if(a1[3].matches("librarian")){
			searchPanel.add(DeleteButton);
		}
		frame.getContentPane().add(searchPanel, BorderLayout.SOUTH);

		frame.setVisible(true);
	}

	private void searchBooksByNameAuthorPublisher(Record record, String searchTerm ,int n) {
		model.setRowCount(0); // Clear existing table data
		boolean booksFound = false;
		// Search by book name

		for (Book b : record.getAllBooks()) {

			if(n==0) {
				if (b.getName().toLowerCase().equalsIgnoreCase(searchTerm.toLowerCase())) {
					addBookToTable(b);
					booksFound = true;
				}
			}
			if(n==1) {
				if (b.getPublisher().equalsIgnoreCase(searchTerm)) {
					addBookToTable(b);
					booksFound = true;
				}
			}
			if(n==2) {
				if (b.getAuthor().equalsIgnoreCase(searchTerm)) {
					addBookToTable(b);
					booksFound = true;
				}
			}
		}
		// If no books found by name or publisher, display message
		if (!booksFound) {
			JOptionPane.showMessageDialog(new JFrame(), "No books found matching the search term!");
		}
	}

	private void addBookToTable(Book book) {
		Vector<Object> rowData = new Vector<>();
		rowData.add(book.getName());
		rowData.add(book.getAuthor());
		rowData.add(book.getPublisher());
		rowData.add(book.getAdress());
		rowData.add(book.getQty());
		rowData.add(book.getPrice());
		rowData.add(book.getBrwcopies());
		model.addRow(rowData);
	}
}
