package com.LibraryManagementSystem.lib.Model;

import com.LibraryManagementSystem.lib.MainPage;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public abstract class User {

	protected String name;
	protected String username;
	protected String pass;
	protected IOOperation[] operations;

	public User() {}

	public User(String name) {
		this.name = name;
	}

	public User(String name, String email, String pass) {
		this.name = name;
		this.username = email;
		this.pass = pass;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return username;
	}

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public IOOperation[] getOperations() {
        return operations;
    }

    public void setOperations(IOOperation[] operations) {
        this.operations = operations;
    }

    public String getPassword() {
		return pass;
	}

	abstract public String toString();

	abstract public void menu(Record record, User user);

	public JFrame frame(String[] data, Record record, User user) {
            JFrame frame = new JFrame();
            frame.setSize(600, 370);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setTitle("Library Management System");
            frame.setLayout(new BorderLayout());
            frame.getContentPane().setBackground(null);
            frame.setBackground(null);

            JLabel label1 = MainPage.title("Welcome to LMS Mr. " + user.getName());
            label1.setFont(new Font("Arial", Font.BOLD, 30));
            frame.getContentPane().add(label1, BorderLayout.NORTH);

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createEmptyBorder(0, 30, 30, 30));
            panel.setBackground(null);

            JPanel buttonsPanel = new JPanel(new GridLayout((int) Math.ceil(data.length / 2.0), 2, 15, 15));
            buttonsPanel.setBackground(null);
            int n;
            if(data.length % 2 ==0 ){ n = data.length;}
            else{n = data.length-1;}
            for (int i = 0; i < n; i++) {
                JButton button = new JButton(data[i]);
                button.setPreferredSize(new Dimension(180, 60));
                button.setFont(new Font("Tahoma", Font.BOLD, 20));
                button.setForeground(Color.black);
                button.setHorizontalAlignment(SwingConstants.CENTER);
                button.setBackground(new Color(102, 204, 255));
                button.setBorder(BorderFactory.createLineBorder(Color.black, 2));
                int index = i;
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        operations[index].operations(record, user);
                        if (data[index].matches("Exit")) {
                            frame.dispose();
                        }
                    }
                });
                buttonsPanel.add(button);
            }
            if(data.length%2 !=0) {
                JButton lastButton = new JButton(data[data.length - 1]);
                lastButton.setPreferredSize(new Dimension(360, 60));
                lastButton.setFont(new Font("Tahoma", Font.BOLD, 15));
                lastButton.setForeground(Color.white);
                lastButton.setHorizontalAlignment(SwingConstants.CENTER);
                lastButton.setBackground(new Color(102, 204, 255));
                lastButton.setBorder(BorderFactory.createLineBorder(Color.black, 2));
                int lastIndex = data.length - 1;
                lastButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        operations[lastIndex].operations(record, user);
                        if (data[lastIndex].matches("Exit")) {
                            frame.dispose();
                        }
                    }
                });
                panel.add(lastButton, BorderLayout.SOUTH);
            }
            panel.add(buttonsPanel, BorderLayout.CENTER);
            frame.getContentPane().add(panel, BorderLayout.CENTER);
            return frame;
}

}
