package com.LibraryManagementSystem.lib.Model;

import com.LibraryManagementSystem.lib.Controller.AddBook;
import com.LibraryManagementSystem.lib.Controller.BorrowedBook;
import com.LibraryManagementSystem.lib.Controller.ViewBooks;
import com.LibraryManagementSystem.lib.Controller.ViewOrders;
import com.LibraryManagementSystem.lib.Exit;

import javax.swing.JFrame;

public class Librarian extends User {
	
	public Librarian(String name) {
		super(name);
		this.operations = new IOOperation[] {
				new ViewBooks(),
				new AddBook(),
				new BorrowedBook(),
				new ViewOrders(),
				new Exit()
		};
	}
	
	public Librarian(String name, String username, String pass) {
		super(name, username, pass);
		this.operations = new IOOperation[] {
				new ViewBooks(),
				new AddBook(),
				new BorrowedBook(),
				new ViewOrders(),
				new Exit()
		};
	}
	
	@Override
	public void menu(Record database, User user) {
		String[] data = new String[4];
		data[0] = "View Books";
		data[1] = "Add Book";
		data[2] = "View Borrowed Books";
		data[3] = "Exit";
		
		JFrame frame = this.frame(data, database, user);
		frame.setVisible(true);
	}
	
	public String toString() {
		return name+"<N/>"+username+"<N/>"+pass+"<N/>"+"librarian";
	}

}
