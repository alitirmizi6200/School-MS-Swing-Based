package com.LibraryManagementSystem.lib.Model;

public interface IOOperation {
	
	public void operations(Record record, User user);

}
