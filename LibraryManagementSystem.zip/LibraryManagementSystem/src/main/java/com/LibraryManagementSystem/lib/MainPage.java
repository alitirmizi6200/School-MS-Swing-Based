package com.LibraryManagementSystem.lib;

import com.LibraryManagementSystem.lib.Model.Record;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPage extends JPanel {
    private JLabel jLabel1;
    private JButton adminModule;
    private JButton userModule;
    static Record record;
    public MainPage() {
        record = new Record();
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        adminModule = new JButton();
        userModule = new JButton();

        jPanel1.setBackground(new Color(255, 255, 255));

        jLabel1.setFont(new Font("Arial", 1, 36));
        jLabel1.setText("Library Management System");

        adminModule.setBackground(new Color(102, 204, 255));
        adminModule.setFont(new Font("Times New Roman", 1, 18));
        adminModule.setText("Admin Login");
        adminModule.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                adminModuleActionPerformed(evt);
            }
        });

        userModule.setBackground(new Color(102, 204, 255));
        userModule.setFont(new Font("Times New Roman", 1, 18));
        userModule.setText("User Login");
        userModule.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                userModuleActionPerformed(evt);
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(104, 104, 104)
                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel1)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(63, 63, 63)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addComponent(userModule, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(adminModule, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(86, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jLabel1)
                                .addGap(50, 50, 50)
                                .addComponent(adminModule, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(userModule, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(74, Short.MAX_VALUE))
        );

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }

    private void adminModuleActionPerformed(ActionEvent evt) {
        // Add your admin module code here
        new AdminLogin(record);

    }

    private void userModuleActionPerformed(ActionEvent evt) {
        new UserLogin(record);
    }

    private JPanel jPanel1;

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new MainPage());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    public static JFrame frame(int width, int height) {
        JFrame frame = new JFrame();
        frame.setSize(width, height);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle("Library Management System");
        frame.setLayout(new BorderLayout());
        frame.setBackground(Color.white);
        frame.getContentPane().setBackground(Color.white);
        return frame;
    }
    public static JLabel label(String text) {
        JLabel label1 = new JLabel(text);
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        label1.setFont(new Font("Tahoma", Font.BOLD, 17));
        label1.setForeground(Color.black);
        return label1;
    }

    public static JTextField textfield() {
        JTextField textfield1 = new JTextField();
        textfield1.setFont(new Font("Tahoma", Font.BOLD, 17));
        textfield1.setForeground(Color.black);
        textfield1.setHorizontalAlignment(SwingConstants.CENTER);
        return textfield1;
    }

    public static JButton button(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Tahoma", Font.BOLD, 17));
        button.setForeground(Color.white);
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setBackground(Color.decode("#1da1f2"));
        button.setBorder(null);
        return button;
    }

    public static JRadioButton radioButton(String text) {
        JRadioButton btn = new JRadioButton();
        btn.setForeground(Color.black);
        btn.setText(text);
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.setFont(new Font("Tahoma", Font.BOLD, 17));
        btn.setBackground(null);
        return btn;
    }

    public static JLabel title(String text) {
        JLabel title = MainPage.label(text);
        title.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        return title;
    }
}
