package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.IOOperation;
import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.User;
import com.LibraryManagementSystem.lib.Model.Book;
import com.LibraryManagementSystem.lib.Model.Borrowing;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DeleteBook implements IOOperation {

	@Override
	public void operations(Record record, User user) {

		JFrame frame = MainPage.frame(400, 210);
		frame.setLayout(new BorderLayout());

		JLabel title = MainPage.title("Delete book");
		frame.getContentPane().add(title, BorderLayout.NORTH);

		JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
		panel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
		panel.setBackground(null);
		JLabel label = MainPage.label("Book Name:");
		JTextField name = MainPage.textfield();
		JButton delete = MainPage.button("Delete Book");
		JButton cancel = MainPage.button("Cancel");
		panel.add(label);
		panel.add(name);
		panel.add(delete);
		panel.add(cancel);

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (name.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Book name cannot be empty!");
					return;
				}
				int bookIndex = record.getBook(name.getText().toString());
				if (bookIndex > -1) {
					Book book = record.getBook(bookIndex);
					boolean isBookBorrowed = isBookBorrowed(record, book);
					if (isBookBorrowed) {
						JOptionPane.showMessageDialog(new JFrame(), "Book is currently borrowed and cannot be deleted!");
					} else {
						record.deleteBook(bookIndex);
						JOptionPane.showMessageDialog(new JFrame(), "Book deleted successfully!");
						frame.dispose();
					}
				} else {
					JOptionPane.showMessageDialog(new JFrame(), "Book doesn't exist!");
				}
			}
		});
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				ViewBooks view = new ViewBooks();
				view.operations(record, user);
			}
		});

		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setVisible(true);

	}

	// Check if a book is currently borrowed
	private boolean isBookBorrowed(Record record, Book book) {
		for (Borrowing borrowing : record.getBrws()) {
			if (borrowing.getBook().equals(book)) {
				return true;
			}
		}
		return false;
	}
}
