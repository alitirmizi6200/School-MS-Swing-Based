package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.Exit;
import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.Librarian;
import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.Student;
import com.LibraryManagementSystem.lib.Model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class newUser{
    public newUser() {
    }

    public void operations(Record record) {
        JFrame frame = MainPage.frame(500, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 15, 20, 15));
        panel.setBackground(null);

        JLabel title = MainPage.label("Create new account");
        title.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JLabel label0 = MainPage.label("Name: ");
        JLabel label1 = MainPage.label("Username: ");
        JLabel label2 = MainPage.label("Password: ");
        JTextField name = MainPage.textfield();
        JTextField username = MainPage.textfield();
        JTextField pass = MainPage.textfield();
        JRadioButton librarian = MainPage.radioButton("Librarian");
        JRadioButton normaluser = MainPage.radioButton("Normal User");
        JButton createacc = MainPage.button("Create Account");
        JButton cancel = MainPage.button("Cancel");

        librarian.addActionListener(e -> {
            if (normaluser.isSelected()) {
                normaluser.setSelected(false);
            }
        });
        normaluser.addActionListener(e -> {
            if (librarian.isSelected()) {
                librarian.setSelected(false);
            }
        });

        panel.add(label0);
        panel.add(name);
        panel.add(label1);
        panel.add(username);
        panel.add(label2);
        panel.add(pass);
        panel.add(librarian);
        panel.add(normaluser);
        panel.add(createacc);
        panel.add(cancel);
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);

        createacc.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {

                                            if (record.userExists(username.getText().toString())) {
                                                JOptionPane.showMessageDialog(new JFrame(), "Username exists!\nTry another one");
                                                return;
                                            }
                                            if (name.getText().toString().matches("")) {
                                                JOptionPane.showMessageDialog(new JFrame(), "Name cannot be empty!");
                                                return;
                                            }
                                            if (username.getText().toString().matches("")) {
                                                JOptionPane.showMessageDialog(new JFrame(), "Uename cannot be empty!");
                                                return;
                                            }
                                            if (pass.getText().toString().matches("")) {
                                                JOptionPane.showMessageDialog(new JFrame(), "Email cannot be empty!");
                                                return;
                                            }
                                            if (!librarian.isSelected() && !normaluser.isSelected()) {
                                                JOptionPane.showMessageDialog(new JFrame(), "You must choose account type!");
                                                return;
                                            }
                                            User user;
                                            if (librarian.isSelected()) {
                                                user = new Librarian(name.getText().toString(), username.getText().toString(),
                                                        pass.getText().toString());
                                            } else {
                                                user = new Student(name.getText().toString(), username.getText().toString(),
                                                        pass.getText().toString());
                                            }
                                            frame.dispose();
                                            record.AddUser(user);
                                            new Exit();
                                        }

                                    }
        );
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });


        frame.setVisible(true);
    }


}
