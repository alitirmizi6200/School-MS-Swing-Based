package com.LibraryManagementSystem.lib;

import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserLogin {
    static Record record;


    private static void Initialize() {
        JFrame frame = MainPage.frame(500, 360);


        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout()); // Changed layout manager to GridBagLayout
        panel.setBorder(BorderFactory.createEmptyBorder(10, 15, 20, 15));
        panel.setBackground(null);

        JLabel title = MainPage.label("Welcome to Library Management System");
        title.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(new Color(102, 204, 255));
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JLabel label1 = MainPage.label("Username:");
        JLabel label2 = MainPage.label("Password:");
        JTextField username = MainPage.textfield();
        JTextField pass = MainPage.textfield();
        JButton login = MainPage.button("Login");

        // Set preferred size using Dimension
        Dimension buttonSize = new Dimension(350, 40);
        username.setPreferredSize(buttonSize);
        username.setMinimumSize(buttonSize);
        username.setMaximumSize(buttonSize);

        pass.setPreferredSize(buttonSize);
        pass.setMinimumSize(buttonSize);
        pass.setMaximumSize(buttonSize);

        login.setPreferredSize(buttonSize);
        login.setMinimumSize(buttonSize);
        login.setMaximumSize(buttonSize);

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (username.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Username cannot be empty!");
                    return;
                }
                if (pass.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "password cannot be empty!");
                    return;
                }

                int n = record.login(username.getText().toString(), pass.getText().toString());
                if (n != -1) {
                    User user = record.getUser(n);
                    user.menu(record, user);
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(new JFrame(), "Username or password is wrong doesn't exist");
                    username.setText("");
                    pass.setText("");

                }

            }
        });

        // Define constraints for GridBagLayout
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 0, 5, 0);

        // Add components to the panel with constraints
        panel.add(label1, constraints);
        constraints.gridy = 1;
        panel.add(username, constraints);
        constraints.gridy = 2;
        panel.add(label2, constraints);
        constraints.gridy = 3;
        panel.add(pass, constraints);
        constraints.gridy = 4;
        panel.add(login, constraints);

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public UserLogin(Record record) {
        this.record = record;
        Initialize();
    }

}
