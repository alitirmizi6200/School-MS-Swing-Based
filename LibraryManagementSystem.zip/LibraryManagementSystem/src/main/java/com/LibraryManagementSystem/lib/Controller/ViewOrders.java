package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.IOOperation;
import com.LibraryManagementSystem.lib.Model.Order;
import com.LibraryManagementSystem.lib.Model.Record;
import com.LibraryManagementSystem.lib.Model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ViewOrders implements IOOperation {

	@Override
	public void operations(Record record, User user) {
		JFrame frame = MainPage.frame(400, 210);
		frame.setLayout(new BorderLayout());

		JLabel title = MainPage.title("View Orders");
		frame.getContentPane().add(title, BorderLayout.NORTH);

		JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
		panel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
		panel.setBackground(null);
		JLabel label = MainPage.label("Book Name:");
		JTextField name = MainPage.textfield();
		JButton view = MainPage.button("View Orders");
		JButton cancel = MainPage.button("Cancel");
		panel.add(label);
		panel.add(name);
		panel.add(view);
		panel.add(cancel);

		view.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (name.getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Book name cannot be empty!");
					return;
				}

				int index = record.getBook(name.getText());
				if (index != -1) {
					List<Order> orders = getOrdersByBook(record.getAllOrders(), name.getText());
					showOrders(orders);
					frame.dispose();
				} else {
					JOptionPane.showMessageDialog(new JFrame(), "Book doesn't exist!");
				}
			}
		});

		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});

		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private void showOrders(List<Order> orders) {
		JFrame frame = MainPage.frame(500, 300);

		JLabel title = MainPage.title("View Orders");
		frame.getContentPane().add(title, BorderLayout.NORTH);

		String[] columnNames = {"Book", "User", "Qty", "Price"};
		Object[][] data = new Object[orders.size()][4];

		for (int i = 0; i < orders.size(); i++) {
			Order order = orders.get(i);
			data[i][0] = order.getBook().getName();
			data[i][1] = order.getUser().getName();
			data[i][2] = order.getQty();
			data[i][3] = order.getPrice();
		}

		DefaultTableModel model = new DefaultTableModel(data, columnNames);
		JTable table = new JTable(model);
		table.setBackground(Color.WHITE);

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));

		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private List<Order> getOrdersByBook(List<Order> orders, String bookName) {
		List<Order> filteredOrders = new ArrayList<>();
		for (Order order : orders) {
			if (order.getBook().getName().equals(bookName)) {
				filteredOrders.add(order);
			}
		}
		return filteredOrders;
	}
}
