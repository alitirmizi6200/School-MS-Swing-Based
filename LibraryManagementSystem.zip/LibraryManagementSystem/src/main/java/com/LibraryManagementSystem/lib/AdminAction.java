package com.LibraryManagementSystem.lib;

import com.LibraryManagementSystem.lib.Controller.DeleteUser;
import com.LibraryManagementSystem.lib.Controller.newUser;
import com.LibraryManagementSystem.lib.Model.Record;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminAction {
    private JLabel jLabel1;
    private JButton addUser;
    private JButton removeUser;
    private JButton exitButton;



    public void operations(Record record)  {

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setTitle("Library Management System");
        frame.setSize(700, 600);
        frame.setLocationRelativeTo(null);

        jPanel1 = new JPanel();
        jPanel1.setBackground(new Color(255, 255, 255));

        jLabel1 = new JLabel();
        jLabel1.setFont(new Font("Arial", Font.BOLD, 36));
        jLabel1.setText("Library Management System");

        addUser = new JButton();
        addUser.setBackground(new Color(102, 204, 255));
        addUser.setFont(new Font("Times New Roman", Font.BOLD, 18));
        addUser.setText("Add User");
        addUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                newUser newUser = new newUser();
                newUser.operations(record);
            }
        });

        removeUser = new JButton();
        removeUser.setBackground(new Color(102, 204, 255));
        removeUser.setFont(new Font("Times New Roman", Font.BOLD, 18));
        removeUser.setText("Remove User");
        removeUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                DeleteUser delUser = new DeleteUser();
                delUser.operations(record);
            }
        });

        exitButton = new JButton();
        exitButton.setBackground(new Color(102, 204, 255));
        exitButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        exitButton.setText("Exit");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                frame.dispose();
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(104, 104, 104)
                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel1)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(63, 63, 63)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addComponent(addUser, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(removeUser, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(exitButton, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(86, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jLabel1)
                                .addGap(50, 50, 50)
                                .addComponent(addUser, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(removeUser, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(exitButton, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(56, Short.MAX_VALUE))
        );

        frame.getContentPane().add(jPanel1, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void addUserActionPerformed(ActionEvent evt) {
        // Add your librarian module code here


    }

    private void removeUserActionPerformed(ActionEvent evt) {
        // Add your user module code here

    }
    private void exitUserActionPerformed(ActionEvent evt) {
        // Add your user module code here

    }
    private JPanel jPanel1;




}
