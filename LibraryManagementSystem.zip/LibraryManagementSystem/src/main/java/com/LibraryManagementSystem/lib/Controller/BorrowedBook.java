package com.LibraryManagementSystem.lib.Controller;

import com.LibraryManagementSystem.lib.MainPage;
import com.LibraryManagementSystem.lib.Model.*;
import com.LibraryManagementSystem.lib.Model.Record;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class BorrowedBook implements IOOperation {


		private JTextField searchField;
		private DefaultTableModel model;

		@Override
		public void operations(Record record, User user) {

			int rows = record.getAllBorrowings().size();
			Vector<String> columnNames = new Vector<>(Arrays.asList("Start Time", "Finish Time", "Days Left", "User", "Book"));
			Vector<Vector<Object>> data = new Vector<>();

			for (Borrowing b : record.getAllBorrowings()) {
				Vector<Object> rowData = new Vector<>();
				rowData.add(b.getStart());
				rowData.add(b.getFinish());
				rowData.add(b.getDaysLeft());
				rowData.add(b.getUser().getName());
				rowData.add(b.getBook().getName());
				data.add(rowData);
			}

			JFrame frame = MainPage.frame(1000, 500);

			JLabel title = MainPage.title("View Borrowing Record");
			frame.getContentPane().add(title, BorderLayout.NORTH);

			model = new DefaultTableModel(data, columnNames);
			JTable table = new JTable(model);

			JScrollPane scrollPane = new JScrollPane(table);
			frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

			JPanel searchPanel = new JPanel();
			searchField = new JTextField(20);
			JButton searchNameButton = new JButton("Search Record by User");
			searchNameButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String searchTerm = searchField.getText();
					if(searchTerm.toString().matches("")){
						JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");

					}
					else{searchRecordByNameOrPublisher(record,searchTerm,0);}
				}
			});

			JButton searchPublisherButton = new JButton("Search Record by Book");
			searchPublisherButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String searchTerm = searchField.getText();
					if(searchTerm.toString().matches("")){
						JOptionPane.showMessageDialog(new JFrame(), "Search Field Empty!");

					}else{searchRecordByNameOrPublisher(record,searchTerm,1);}

				}
			});

			searchPanel.add(searchField);
			searchPanel.add(searchNameButton);
			searchPanel.add(searchPublisherButton);
			frame.getContentPane().add(searchPanel, BorderLayout.SOUTH);

			frame.setVisible(true);
		}

		private void searchRecordByNameOrPublisher(Record record, String searchTerm ,int n) {
			model.setRowCount(0); // Clear existing table data
			boolean recordFound = false;

			// Search by book name
			if(n==0) {
				for (Borrowing b : record.getAllBorrowings()) {
					if (b.getUser().getName().equalsIgnoreCase(searchTerm)) {
						addBorrowRecordToTable(b);
						recordFound = true;
					}
				}
				if (!recordFound) {
					JOptionPane.showMessageDialog(new JFrame(), "No Record found matching the search term!");
				}
			}
			// If no books found by name, search by publisher
			if (n==1) {
				for (Borrowing b : record.getAllBorrowings()) {
					if (b.getBook().getName().equalsIgnoreCase(searchTerm)) {
						addBorrowRecordToTable(b);
						recordFound = true;
					}
				}
				if (!recordFound) {
					JOptionPane.showMessageDialog(new JFrame(), "No Record found matching the search term!");
				}
			}


		}

		private void addBorrowRecordToTable(Borrowing b) {
			Vector<Object> rowData = new Vector<>();
			rowData.add(b.getStart());
			rowData.add(b.getFinish());
			rowData.add(b.getDaysLeft());
			rowData.add(b.getUser().getName());
			rowData.add(b.getBook().getName());
			model.addRow(rowData);
		}
	}


